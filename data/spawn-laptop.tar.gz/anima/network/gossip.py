"""Gossip mesh — unified heartbeat + state exchange + failure detection.

Single 5s timer does three things:
1. PUB own state_vector (all nodes receive)
2. Random-select 2 neighbors for state exchange
3. Update failure detector (Phi Accrual)
"""

import asyncio
import math
import random
import time
from collections import defaultdict
from typing import Callable, Any

import zmq
import zmq.asyncio

from anima.network.protocol import NetworkMessage
from anima.network.node import NodeState, NodeStatus, NodeIdentity
from anima.utils.logging import get_logger

log = get_logger("network.gossip")


class PhiAccrualDetector:
    """Phi Accrual failure detector — adaptive timeout based on heartbeat history."""

    def __init__(self, window_size: int = 100):
        self._intervals: dict[str, list[float]] = defaultdict(list)
        self._last_seen: dict[str, float] = {}
        self._window = window_size

    def report_heartbeat(self, node_id: str) -> None:
        now = time.time()
        if node_id in self._last_seen:
            interval = now - self._last_seen[node_id]
            history = self._intervals[node_id]
            history.append(interval)
            if len(history) > self._window:
                history.pop(0)
        self._last_seen[node_id] = now

    def phi(self, node_id: str) -> float:
        """Calculate phi value. Higher = more likely dead."""
        if node_id not in self._last_seen:
            return 0.0
        history = self._intervals.get(node_id, [])
        if len(history) < 3:
            # Not enough data — use simple timeout (30s)
            elapsed = time.time() - self._last_seen[node_id]
            return elapsed / 5.0  # phi=1 per 5s of silence

        mean = sum(history) / len(history)
        variance = sum((x - mean) ** 2 for x in history) / len(history)
        stddev = max(math.sqrt(variance), 0.1)

        elapsed = time.time() - self._last_seen[node_id]
        if elapsed <= mean:
            return 0.0

        # Approximate phi using normal distribution CDF
        y = (elapsed - mean) / stddev
        # Simplified phi = -log10(1 - CDF(y)) ~ y^2 / 2 for large y
        phi_val = max(0, y * y / 2.0)
        return phi_val


class GossipMesh:
    """Unified gossip mesh with heartbeat, state exchange, and failure detection."""

    GOSSIP_INTERVAL = 5.0  # seconds
    SUSPECT_PHI = 8.0
    DEAD_PHI = 16.0

    def __init__(
        self,
        identity: NodeIdentity,
        local_state: NodeState,
        network_secret: str = "",
        listen_port: int = 9420,
    ):
        self._identity = identity
        self._local_state = local_state
        self._secret = network_secret
        self._port = listen_port

        self._peers: dict[str, NodeState] = {}  # node_id -> last known state
        self._peer_addresses: dict[str, str] = {}  # node_id -> "ip:port"
        self._detector = PhiAccrualDetector()
        self._running = False
        self._task: asyncio.Task | None = None

        # ZMQ context
        self._ctx = zmq.asyncio.Context()
        self._pub: zmq.asyncio.Socket | None = None
        self._sub: zmq.asyncio.Socket | None = None

        # Callbacks
        self._on_node_alive: Callable | None = None
        self._on_node_suspect: Callable | None = None
        self._on_node_dead: Callable | None = None
        self._on_event: Callable | None = None

    def set_callbacks(
        self,
        on_node_alive: Callable | None = None,
        on_node_suspect: Callable | None = None,
        on_node_dead: Callable | None = None,
        on_event: Callable | None = None,
    ):
        self._on_node_alive = on_node_alive
        self._on_node_suspect = on_node_suspect
        self._on_node_dead = on_node_dead
        self._on_event = on_event

    def add_peer(self, address: str) -> None:
        """Add a peer address (ip:port) to connect to."""
        if self._sub:
            self._sub.connect(f"tcp://{address}")
            log.info("Connected to peer: %s", address)

    async def start(self) -> None:
        """Start the gossip mesh."""
        self._running = True

        # PUB socket — broadcast our state
        self._pub = self._ctx.socket(zmq.PUB)
        self._pub.bind(f"tcp://*:{self._port}")

        # SUB socket — receive others' state
        self._sub = self._ctx.socket(zmq.SUB)
        self._sub.setsockopt(zmq.SUBSCRIBE, b"")
        self._sub.setsockopt(zmq.RCVTIMEO, 100)  # 100ms timeout for non-blocking

        # Connect to configured peers
        for addr in self._peer_addresses.values():
            self._sub.connect(f"tcp://{addr}")

        self._task = asyncio.create_task(self._gossip_loop())
        log.info("Gossip mesh started on port %d", self._port)

    async def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        if self._pub:
            self._pub.close()
        if self._sub:
            self._sub.close()
        self._ctx.term()
        log.info("Gossip mesh stopped")

    async def broadcast_event(self, event_data: dict) -> None:
        """Broadcast an event to all nodes."""
        msg = NetworkMessage(
            type="event",
            source_node=self._identity.node_id,
            target_node="*",
            payload=event_data,
        )
        if self._secret:
            msg.sign(self._secret)
        if self._pub:
            await self._pub.send(msg.pack())

    def get_peers(self) -> dict[str, NodeState]:
        return dict(self._peers)

    def get_alive_peers(self) -> dict[str, NodeState]:
        return {nid: s for nid, s in self._peers.items() if s.status == "alive"}

    def get_alive_count(self) -> int:
        """Count of alive nodes including self."""
        return 1 + sum(1 for s in self._peers.values() if s.status == "alive")

    def configure_peers(self, peer_list: list[str]) -> None:
        """Set initial peer addresses from config."""
        for addr in peer_list:
            # We don't know node_ids yet, use address as temporary key
            self._peer_addresses[addr] = addr
            if self._sub:
                self._sub.connect(f"tcp://{addr}")
                log.info("Connected to peer: %s", addr)

    # ── Internal loop ──

    async def _gossip_loop(self) -> None:
        while self._running:
            try:
                # 1. Update local state
                self._local_state.bump_version()
                self._local_state.uptime_s = int(time.time() - self._local_state.heartbeat_ts) if self._local_state.heartbeat_ts else 0

                # 2. Broadcast own state (PUB)
                msg = NetworkMessage(
                    type="gossip",
                    source_node=self._identity.node_id,
                    target_node="*",
                    payload=self._local_state.to_dict(),
                )
                if self._secret:
                    msg.sign(self._secret)
                if self._pub:
                    await self._pub.send(msg.pack())

                # 3. Receive and process incoming messages
                await self._receive_messages()

                # 4. Update failure detector
                self._check_failures()

            except asyncio.CancelledError:
                return
            except Exception as e:
                log.error("Gossip loop error: %s", e)

            await asyncio.sleep(self.GOSSIP_INTERVAL)

    async def _receive_messages(self) -> None:
        """Receive all pending messages from SUB socket."""
        if not self._sub:
            return

        while True:
            try:
                data = await asyncio.wait_for(
                    self._sub.recv(zmq.NOBLOCK), timeout=0.05
                )
            except (zmq.Again, asyncio.TimeoutError):
                break
            except Exception:
                break

            try:
                msg = NetworkMessage.unpack(data)

                # Skip own messages
                if msg.source_node == self._identity.node_id:
                    continue

                # Verify signature if secret is set
                if self._secret and not msg.verify(self._secret):
                    log.warning("Invalid signature from %s, dropping", msg.source_node)
                    continue

                if msg.type == "gossip":
                    self._handle_gossip(msg)
                elif msg.type == "event":
                    if self._on_event:
                        self._on_event(msg.payload)

            except Exception as e:
                log.debug("Failed to process message: %s", e)

    def _handle_gossip(self, msg: NetworkMessage) -> None:
        """Handle incoming gossip state vector."""
        remote_state = NodeState.from_dict(msg.payload)
        node_id = msg.source_node

        # Update peer state
        old_state = self._peers.get(node_id)
        old_status = old_state.status if old_state else None

        if old_state is None or remote_state.version > old_state.version:
            remote_state.status = "alive"
            self._peers[node_id] = remote_state

            # Register node if new
            self._identity.register_node(node_id)

            # Update peer address mapping
            if remote_state.ip and remote_state.port:
                addr = f"{remote_state.ip}:{remote_state.port}"
                if node_id not in self._peer_addresses:
                    self._peer_addresses[node_id] = addr
                    if self._sub:
                        self._sub.connect(f"tcp://{addr}")

        # Report heartbeat to failure detector
        self._detector.report_heartbeat(node_id)

        # Status transition callbacks
        if old_status != "alive" and remote_state.status == "alive":
            if self._on_node_alive:
                self._on_node_alive(node_id, remote_state)
            log.info("Node alive: %s (%s)", node_id, remote_state.hostname)

    def _check_failures(self) -> None:
        """Check all known peers for failure using Phi Accrual."""
        for node_id, state in list(self._peers.items()):
            if state.status in ("dead", "isolated"):
                continue

            phi = self._detector.phi(node_id)

            if phi >= self.DEAD_PHI and state.status != "dead":
                state.status = "dead"
                self._identity.update_node_status(node_id, "dead")
                if self._on_node_dead:
                    self._on_node_dead(node_id, state)
                log.warning("Node DEAD: %s (phi=%.1f)", node_id, phi)

            elif phi >= self.SUSPECT_PHI and state.status == "alive":
                state.status = "suspect"
                if self._on_node_suspect:
                    self._on_node_suspect(node_id, state)
                log.warning("Node SUSPECT: %s (phi=%.1f)", node_id, phi)
