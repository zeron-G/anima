"""Discord channel — Discord bot integration.

Requires: pip install discord.py
Config: channels.discord.token in default.yaml or DISCORD_BOT_TOKEN env var
"""

from __future__ import annotations
import asyncio
import os

from anima.channels.base import BaseChannel
from anima.utils.logging import get_logger

log = get_logger("channels.discord")


class DiscordChannel(BaseChannel):
    """Discord bot channel.

    Receives DMs and mentions, sends replies to the same channel.
    """

    def __init__(self, token: str = "", allowed_users: list[str] | None = None):
        super().__init__("discord")
        self._token = token or os.environ.get("DISCORD_BOT_TOKEN", "")
        self._allowed_users = set(allowed_users or [])
        self._client = None
        self._connected = False
        self._response_targets: dict[str, int] = {}  # session_id -> channel_id

    async def start(self) -> None:
        if not self._token:
            log.warning("Discord token not configured, skipping")
            return

        try:
            import discord
        except ImportError:
            log.warning("discord.py not installed. Run: pip install discord.py")
            return

        intents = discord.Intents.default()
        intents.message_content = True
        self._client = discord.Client(intents=intents)

        @self._client.event
        async def on_ready():
            self._connected = True
            log.info("Discord connected as %s", self._client.user)

        @self._client.event
        async def on_message(message):
            if message.author == self._client.user:
                return

            # Check if user is allowed (if allowlist is set)
            if self._allowed_users and str(message.author.id) not in self._allowed_users:
                return

            # Store response target
            session_id = f"discord:{message.author.id}"
            self._response_targets[session_id] = message.channel.id

            if self._on_message:
                await self._on_message({
                    "text": message.content,
                    "user": str(message.author.id),
                    "user_name": message.author.display_name,
                    "channel": "discord",
                    "channel_id": str(message.channel.id),
                    "guild": message.guild.name if message.guild else "DM",
                    "source": session_id,
                })

        # Run in background (non-blocking)
        asyncio.create_task(self._run_client())

    async def _run_client(self) -> None:
        try:
            await self._client.start(self._token)
        except Exception as e:
            log.error("Discord client error: %s", e)
            self._connected = False

    async def stop(self) -> None:
        self._connected = False
        if self._client:
            await self._client.close()
        log.info("Discord channel stopped")

    async def send(self, target: str, text: str) -> bool:
        """Send a message. target = session_id (e.g., 'discord:123456')."""
        if not self._client or not self._connected:
            return False

        channel_id = self._response_targets.get(target)
        if not channel_id:
            log.warning("No response target for session %s", target)
            return False

        try:
            channel = self._client.get_channel(channel_id)
            if channel is None:
                channel = await self._client.fetch_channel(channel_id)

            # Split long messages (Discord limit: 2000 chars)
            for i in range(0, len(text), 1900):
                await channel.send(text[i:i+1900])
            return True
        except Exception as e:
            log.error("Discord send error: %s", e)
            return False

    @property
    def is_connected(self) -> bool:
        return self._connected
