# ANIMA Node Bootstrap — Windows PowerShell
$ErrorActionPreference = "Stop"
$ANIMA_DIR = if ($env:ANIMA_INSTALL_DIR) { $env:ANIMA_INSTALL_DIR } else { "$env:USERPROFILE\.anima" }
$PYTHON = if ($env:PYTHON_CMD) { $env:PYTHON_CMD } else { "python" }
Write-Host "=== ANIMA Node Bootstrap ==="
Write-Host "Install dir: $ANIMA_DIR"
& $PYTHON --version
if ($LASTEXITCODE -ne 0) { throw "Python 3.11+ required" }
New-Item -ItemType Directory -Force -Path $ANIMA_DIR | Out-Null
Copy-Item -Recurse -Force .\* $ANIMA_DIR\
Set-Location $ANIMA_DIR
& $PYTHON -m venv .venv
.\.venv\Scripts\Activate
pip install -e . --quiet
Start-Process -NoNewWindow -FilePath python -ArgumentList "-m anima" -RedirectStandardOutput "data\logs\anima.log"
Write-Host "=== ANIMA started ==="
