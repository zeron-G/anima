#!/bin/bash
# ANIMA Node Bootstrap — one-command deployment
set -e
ANIMA_DIR="${ANIMA_INSTALL_DIR:-$HOME/.anima}"
PYTHON="${PYTHON_CMD:-python3}"
echo "=== ANIMA Node Bootstrap ==="
echo "Install dir: $ANIMA_DIR"
# Check Python
$PYTHON --version || { echo "ERROR: Python 3.11+ required"; exit 1; }
# Create install dir
mkdir -p "$ANIMA_DIR"
cp -r ./* "$ANIMA_DIR/" 2>/dev/null || true
cd "$ANIMA_DIR"
# Create venv
$PYTHON -m venv .venv
source .venv/bin/activate
# Install
pip install -e . --quiet 2>&1 | tail -3
# Permissions
chmod 600 .env 2>/dev/null || true
# Start
nohup python -m anima > data/logs/anima.log 2>&1 &
echo $! > data/anima.pid
echo "=== ANIMA started (PID: $(cat data/anima.pid)) ==="
echo "Dashboard: http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo localhost):$(python -c 'import yaml; print(yaml.safe_load(open("config/default.yaml")).get("dashboard",{}).get("port",8420))')"
